import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { LayoutGrid } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const existing = localStorage.getItem("edugridUser");
    if (existing) navigate("/", { replace: true });
  }, [navigate]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    // Mock auth: store username and redirect
    localStorage.setItem("edugridUser", username.trim());
    navigate("/", { replace: true });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(210_80%_98%)] to-[hsl(210_60%_94%)] flex items-center justify-center p-4">
      <div className="absolute top-6 left-6 flex items-center gap-2">
        <div className="h-9 w-9 rounded-lg bg-primary/10 grid place-items-center text-primary">
          <LayoutGrid className="h-5 w-5" />
        </div>
        <span className="text-2xl font-extrabold tracking-tight text-foreground">EduGrid</span>
      </div>
      <div className="w-full max-w-md bg-card/90 backdrop-blur supports-[backdrop-filter]:bg-card/70 rounded-xl shadow-xl border p-8">
        <h1 className="text-2xl font-bold text-center mb-2">Welcome back</h1>
        <p className="text-center text-muted-foreground mb-8">Sign in to your EduGrid dashboard</p>
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="username" className="block text-sm font-medium">Username</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="w-full h-11 px-3 rounded-md border bg-background focus:outline-none focus:ring-2 focus:ring-primary/40"
              autoComplete="username"
              required
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium">Password</label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full h-11 px-3 pr-24 rounded-md border bg-background focus:outline-none focus:ring-2 focus:ring-primary/40"
                autoComplete="current-password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute inset-y-0 right-2 my-1 px-3 text-sm rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>
          <Button type="submit" className="w-full h-11 text-base font-semibold">Login</Button>
        </form>
        <p className="mt-6 text-xs text-center text-muted-foreground">Demo login – any username/password will sign you in</p>
      </div>
    </div>
  );
}
