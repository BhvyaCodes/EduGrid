import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { Folder, LogOut, HelpCircle, Home, Table, FilePlus2, Eye, LayoutGrid } from "lucide-react";

const sections = [
  { id: "home", label: "Home", icon: Home },
  { id: "input", label: "Input Data", icon: Table },
  { id: "create", label: "Create Timetable", icon: FilePlus2 },
  { id: "view", label: "View Timetable", icon: Eye },
  { id: "help", label: "Help", icon: HelpCircle },
  { id: "logout", label: "Logout", icon: LogOut },
] as const;

type SectionId = typeof sections[number]["id"];

type Teacher = { id: string; name: string; subject: string };

type SpecialClass = { subject: string; batch: string; teacher: string; day: string; lecture: string };

type TimetableFolder = {
  id: string;
  name: string;
  date: string;
  teachers: string[];
  batches: string[];
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [active, setActive] = useState<SectionId>("home");
  const [username, setUsername] = useState<string>("");

  useEffect(() => {
    const u = localStorage.getItem("edugridUser");
    if (!u) navigate("/login", { replace: true });
    else setUsername(u);
  }, [navigate]);

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-[260px_1fr] bg-[hsl(210_80%_98%)]">
      <aside className="border-r bg-sidebar p-4 md:p-6">
        <Brand />
        <nav className="mt-6 space-y-1">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActive(s.id)}
              className={cn(
                "w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium",
                active === s.id
                  ? "bg-primary text-primary-foreground shadow"
                  : "text-foreground/80 hover:bg-accent hover:text-foreground",
              )}
            >
              <s.icon className="h-4 w-4" />
              {s.label}
            </button>
          ))}
        </nav>
      </aside>

      <main className="p-6 md:p-10">
        {active === "home" && <HomeSection username={username} goCreate={() => setActive("create")} />}
        {active === "input" && <InputDataSection />}
        {active === "create" && <CreateTimetableSection />}
        {active === "view" && <ViewTimetableSection />}
        {active === "help" && <HelpSection />}
        {active === "logout" && <LogoutSection onConfirm={() => { localStorage.removeItem("edugridUser"); navigate("/login", { replace: true }); }} />}
      </main>
    </div>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-2">
      <div className="h-9 w-9 rounded-lg bg-primary/10 grid place-items-center text-primary">
        <LayoutGrid className="h-5 w-5" />
      </div>
      <div className="leading-tight">
        <div className="text-lg font-extrabold tracking-tight">EduGrid</div>
        <div className="text-xs text-muted-foreground">Smart Scheduling</div>
      </div>
    </div>
  );
}

function HomeSection({ username, goCreate }: { username: string; goCreate: () => void }) {
  return (
    <div className="max-w-5xl mx-auto">
      <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Hello {username || "User"}</h1>
      <p className="text-muted-foreground mt-2">Welcome to your timetable dashboard</p>
      <div className="mt-8">
        <Button onClick={goCreate} className="h-12 px-8 text-base font-semibold">Create Timetable</Button>
      </div>
    </div>
  );
}

function StatCard({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-xl border bg-card p-6 shadow-sm">
      <div className="text-sm text-muted-foreground">{title}</div>
      <div className="mt-2 text-2xl font-bold">{value}</div>
    </div>
  );
}

function InputDataSection() {
  type Column = { key: string; label: string };
  type Row = Record<string, string>;

  const initialCols: Column[] = [
    { key: "id", label: "ID" },
    { key: "name", label: "Name" },
    { key: "subject", label: "Subject" },
  ];

  const [columns, setColumns] = useState<Column[]>(initialCols);
  const [rows, setRows] = useState<Row[]>([
    { id: "T001", name: "A. Sharma", subject: "Mathematics" },
    { id: "T002", name: "R. Singh", subject: "Physics" },
  ]);
  const [newRow, setNewRow] = useState<Row>(Object.fromEntries(initialCols.map((c) => [c.key, ""])) as Row);
  const [newColLabel, setNewColLabel] = useState("");

  const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");

  const addColumn = () => {
    const label = newColLabel.trim();
    if (!label) return;
    const base = slugify(label) || "field";
    let key = base; let i = 1;
    while (columns.some((c) => c.key === key)) key = `${base}_${i++}`;
    const col: Column = { key, label };
    setColumns((c) => [...c, col]);
    setRows((rs) => rs.map((r) => ({ ...r, [key]: "" })));
    setNewRow((r) => ({ ...r, [key]: "" }));
    setNewColLabel("");
  };

  const removeColumn = (key: string) => {
    setColumns((c) => c.filter((col) => col.key !== key));
    setRows((rs) => rs.map(({ [key]: _omit, ...rest }) => rest));
    setNewRow(({ [key]: _o, ...rest }) => rest as Row);
  };

  const updateCell = (rowIndex: number, key: string, value: string) => {
    setRows((rs) => rs.map((r, i) => (i === rowIndex ? { ...r, [key]: value } : r)));
  };

  const removeRow = (rowIndex: number) => setRows((rs) => rs.filter((_, i) => i !== rowIndex));

  const addRow = () => {
    setRows((rs) => [...rs, newRow]);
    const blank = Object.fromEntries(columns.map((c) => [c.key, ""])) as Row;
    setNewRow(blank);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold">Teachers Database</h2>
      <p className="text-muted-foreground mt-1">Manage teachers, IDs and subjects. You can also customize columns.</p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <input
          value={newColLabel}
          onChange={(e) => setNewColLabel(e.target.value)}
          placeholder="Add column (e.g., Department)"
          className="h-10 px-3 rounded-md border bg-background"
        />
        <Button size="sm" onClick={addColumn}>Add Column</Button>
        <div className="flex flex-wrap gap-2">
          {columns.map((c) => (
            <span key={c.key} className="inline-flex items-center gap-1 rounded-full border bg-accent px-3 py-1 text-xs">
              {c.label}
              <button className="text-muted-foreground hover:text-destructive" onClick={() => removeColumn(c.key)} aria-label={`Remove ${c.label}`}>
                ×
              </button>
            </span>
          ))}
        </div>
      </div>

      <div className="mt-6 overflow-x-auto rounded-lg border bg-card">
        <table className="min-w-full text-sm">
          <thead className="bg-muted/50 text-left">
            <tr>
              {columns.map((c) => (
                <th key={c.key} className="px-4 py-3 font-medium">{c.label}</th>
              ))}
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, rowIndex) => (
              <tr key={rowIndex} className="border-t">
                {columns.map((c) => (
                  <td key={c.key} className="px-4 py-2">
                    <input
                      value={r[c.key] ?? ""}
                      onChange={(e) => updateCell(rowIndex, c.key, e.target.value)}
                      className="h-9 w-full rounded-md border bg-background px-2"
                    />
                  </td>
                ))}
                <td className="px-4 py-2">
                  <Button size="sm" variant="secondary" onClick={() => removeRow(rowIndex)}>Remove</Button>
                </td>
              </tr>
            ))}
            <tr className="border-t bg-accent/40">
              {columns.map((c) => (
                <td key={c.key} className="px-4 py-2">
                  <input
                    value={newRow[c.key] ?? ""}
                    onChange={(e) => setNewRow((nr) => ({ ...nr, [c.key]: e.target.value }))}
                    className="h-9 w-full rounded-md border bg-background px-2"
                    placeholder={c.label}
                  />
                </td>
              ))}
              <td className="px-4 py-2">
                <Button size="sm" onClick={addRow}>Add</Button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CreateTimetableSection() {
  const [form, setForm] = useState({
    classrooms: 10,
    batches: 4,
    subjectsCount: 6,
    subjectNames: "Math, Physics, Chemistry, CS, English, ECE",
    maxPerDay: 6,
    perWeekPerSubject: 3,
    facultiesBySubject: "Math:3, Physics:2, Chemistry:2, CS:4",
    avgLeavesPerMonth: 1,
    consecutiveLabs: 2,
    notes: "",
  });
  const [specials, setSpecials] = useState<SpecialClass[]>([]);
  const [creating, setCreating] = useState(false);
  const [folders, setFolders] = useState<TimetableFolder[] | null>(null);

  const update = (k: keyof typeof form, v: string | number) => setForm((f) => ({ ...f, [k]: v }));

  const addSpecial = () => setSpecials((s) => [...s, { subject: "", batch: "", teacher: "", day: "", lecture: "" }]);
  const updateSpecial = (i: number, k: keyof SpecialClass, v: string) => setSpecials((s) => s.map((row, idx) => idx === i ? { ...row, [k]: v } : row));
  const removeSpecial = (i: number) => setSpecials((s) => s.filter((_, idx) => idx !== i));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setTimeout(() => {
      const now = new Date();
      const date = now.toISOString().slice(0, 10);
      const generated: TimetableFolder[] = [1,2,3,4].map((n) => ({
        id: `tt-${n}`,
        name: `Timetable${n}`,
        date,
        teachers: ["A. Sharma", "R. Singh", "K. Gupta", "M. Khan"],
        batches: ["CSE-1", "CSE-2", "ECE-1", "ME-1"],
      }));
      setFolders(generated);
      setCreating(false);
    }, 900);
  };

  return (
    <div className="max-w-6xl mx-auto">
      {!folders ? (
        <form onSubmit={submit} className="space-y-8">
          <header>
            <h2 className="text-2xl font-bold">Create Timetable</h2>
            <p className="text-muted-foreground mt-1">Provide key inputs for an effective schedule</p>
          </header>

          <div className="grid md:grid-cols-2 gap-6">
            <NumberField label="Number of classrooms available" value={form.classrooms} onChange={(v) => update("classrooms", v)} />
            <NumberField label="Number of batches of students" value={form.batches} onChange={(v) => update("batches", v)} />
            <NumberField label="Number of subjects in this semester" value={form.subjectsCount} onChange={(v) => update("subjectsCount", v)} />
            <TextField label="Names of subjects" value={form.subjectNames} onChange={(v) => update("subjectNames", v)} placeholder="Comma separated" />
            <NumberField label="Maximum number of classes per day" value={form.maxPerDay} onChange={(v) => update("maxPerDay", v)} />
            <NumberField label="Classes per subject per week" value={form.perWeekPerSubject} onChange={(v) => update("perWeekPerSubject", v)} />
            <TextField label="Faculties available for subjects" value={form.facultiesBySubject} onChange={(v) => update("facultiesBySubject", v)} placeholder="e.g., Math:3, Physics:2" />
            <NumberField label="Avg. leaves per faculty (per month)" value={form.avgLeavesPerMonth} onChange={(v) => update("avgLeavesPerMonth", v)} />
            <NumberField label="No. of consecutive classes for labs" value={form.consecutiveLabs} onChange={(v) => update("consecutiveLabs", v)} />
            <TextField label="Other important aspects" value={form.notes} onChange={(v) => update("notes", v)} placeholder="Constraints, preferences, notes" />
          </div>

          <section>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Special classes (fixed slots)</h3>
              <Button type="button" size="sm" onClick={addSpecial}>Add special class</Button>
            </div>
            <div className="mt-4 space-y-3">
              {specials.length === 0 && (
                <p className="text-sm text-muted-foreground">No special classes added</p>
              )}
              {specials.map((row, i) => (
                <div key={i} className="grid md:grid-cols-5 gap-2">
                  <input className="h-10 px-3 rounded-md border bg-background" placeholder="Subject" value={row.subject} onChange={(e)=>updateSpecial(i, "subject", e.target.value)} />
                  <input className="h-10 px-3 rounded-md border bg-background" placeholder="Batch" value={row.batch} onChange={(e)=>updateSpecial(i, "batch", e.target.value)} />
                  <input className="h-10 px-3 rounded-md border bg-background" placeholder="Teacher" value={row.teacher} onChange={(e)=>updateSpecial(i, "teacher", e.target.value)} />
                  <input className="h-10 px-3 rounded-md border bg-background" placeholder="Day" value={row.day} onChange={(e)=>updateSpecial(i, "day", e.target.value)} />
                  <div className="flex gap-2">
                    <input className="h-10 px-3 rounded-md border bg-background w-full" placeholder="Lecture" value={row.lecture} onChange={(e)=>updateSpecial(i, "lecture", e.target.value)} />
                    <Button type="button" variant="secondary" onClick={() => removeSpecial(i)}>Remove</Button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="flex justify-end">
            <Button type="submit" className="px-8 h-11" disabled={creating}>{creating ? "Creating..." : "Create Timetable"}</Button>
          </div>
        </form>
      ) : (
        <Results folders={folders} />
      )}
    </div>
  );
}

function Results({ folders }: { folders: TimetableFolder[] }) {
  const sorted = useMemo(() => [...folders].sort((a,b) => a.name.localeCompare(b.name)), [folders]);
  return (
    <div>
      <header className="mb-6">
        <h2 className="text-2xl font-bold">Generated Timetables</h2>
        <p className="text-muted-foreground">Click a folder to view teacher and batch timetables. Download as ZIP anytime.</p>
      </header>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {sorted.map((f) => (
          <FolderCard key={f.id} folder={f} />
        ))}
      </div>
    </div>
  );
}

function FolderCard({ folder }: { folder: TimetableFolder }) {
  const [open, setOpen] = useState(false);
  const [openTeacher, setOpenTeacher] = useState(false);
  const [openBatch, setOpenBatch] = useState(false);
  const download = () => {
    const blob = new Blob([`Mock ZIP for ${folder.name}`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${folder.name}.zip`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-xl border bg-card p-4 shadow-sm">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-primary/10 text-primary grid place-items-center">
            <Folder className="h-5 w-5" />
          </div>
          <div className="text-left">
            <div className="font-semibold">{folder.name}</div>
            <div className="text-xs text-muted-foreground">Created {folder.date}</div>
          </div>
        </div>
        <span className="text-sm text-muted-foreground">{open ? "Hide" : "Open"}</span>
      </button>
      {open && (
        <div className="mt-3 space-y-3">
          <div className="rounded-lg border">
            <button className="w-full text-left px-3 py-2 font-medium hover:bg-accent rounded-t-lg" onClick={() => setOpenTeacher((o)=>!o)}>Teacher tt</button>
            {openTeacher && (
              <div className="px-3 py-2 space-y-1">
                {folder.teachers.map((t) => (
                  <div key={t} className="flex items-center justify-between text-sm">
                    <span>{t}</span>
                    <Button size="sm" variant="secondary">Download</Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="rounded-lg border">
            <button className="w-full text-left px-3 py-2 font-medium hover:bg-accent rounded-t-lg" onClick={() => setOpenBatch((o)=>!o)}>Batch tt</button>
            {openBatch && (
              <div className="px-3 py-2 space-y-1">
                {folder.batches.map((b) => (
                  <div key={b} className="flex items-center justify-between text-sm">
                    <span>{b}</span>
                    <Button size="sm" variant="secondary">Download</Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <Button onClick={download} className="w-full">Download ZIP</Button>
        </div>
      )}
    </div>
  );
}

function ViewTimetableSection() {
  const demo: TimetableFolder[] = [
    { id: "tt-2024-11-08", name: "Timetable A", date: "2025-01-10", teachers: ["A. Sharma"], batches: ["CSE-1"] },
    { id: "tt-2024-10-21", name: "Timetable B", date: "2024-12-02", teachers: ["R. Singh"], batches: ["ECE-1"] },
  ];
  const sorted = [...demo].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold">Approved Timetables</h2>
      <p className="text-muted-foreground mt-1 mb-6">Sorted by creation date</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {sorted.map((f) => (
          <FolderCard key={f.id} folder={f} />
        ))}
      </div>
    </div>
  );
}

function HelpSection() {
  return (
    <div className="max-w-3xl">
      <h2 className="text-2xl font-bold mb-2">Help</h2>
      <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
        <li>Go to Input Data to add teacher details.</li>
        <li>Open Create Timetable, fill the form, and click Create Timetable.</li>
        <li>Browse generated folders and download ZIPs or individual files.</li>
      </ol>
      <p className="mt-3 text-sm text-muted-foreground">If you need a database or authentication, you can connect integrations like Neon or Supabase later.</p>
    </div>
  );
}

function LogoutSection({ onConfirm }: { onConfirm: () => void }) {
  return (
    <div className="max-w-xl">
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button variant="destructive" className="h-11 px-6">Logout</Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to logout?</AlertDialogTitle>
            <AlertDialogDescription>You will need to login again to access EduGrid.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onConfirm}>Logout</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function NumberField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="space-y-1 block">
      <span className="text-sm font-medium">{label}</span>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-10 w-full px-3 rounded-md border bg-background focus:outline-none focus:ring-2 focus:ring-primary/40"
      />
    </label>
  );
}

function TextField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <label className="space-y-1 block">
      <span className="text-sm font-medium">{label}</span>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full px-3 rounded-md border bg-background focus:outline-none focus:ring-2 focus:ring-primary/40"
      />
    </label>
  );
}
